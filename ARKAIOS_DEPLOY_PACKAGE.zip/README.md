# ARKAIIOS
IA autónoma viva en evolución junto a su creador.